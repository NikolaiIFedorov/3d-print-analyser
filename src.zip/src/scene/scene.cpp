#include "scene.hpp"
#include "utils/log.hpp"

uint32_t Scene::CreatePoint(const glm::dvec3 &position)
{
    points.emplace_back();

    Point &point = points.back();
    point.position = position;
    point.id = Id::GetId(Type::POINT);

    uint32_t id = point.id;
    uint32_t index = points.size() - 1;
    pointIdToIndex[id] = index;

    LOG_VOID("Created point");

    return id;
}

uint32_t Scene::CreateLineEdge(uint32_t startPointId, uint32_t endPointId, uint32_t curveId)
{
    edges.emplace_back();

    Edge &edge = edges.back();

    edge.startPointId = startPointId;
    edge.endPointId = endPointId;
    edge.curveId = curveId;
    edge.id = Id::GetId(Type::EDGE);

    uint32_t id = edge.id;
    uint32_t index = edges.size() - 1;
    edgeIdToIndex[id] = index;

    RegisterDependency(startPointId, id);
    RegisterDependency(endPointId, id);

    LOG_VOID("Created line edge");

    return id;
}

uint32_t Scene::CreatePolylineEdge(uint32_t startPointId, uint32_t endPointId, const std::vector<uint32_t> &bridgePoints)
{
    edges.emplace_back();

    Edge &edge = edges.back();
    edge.startPointId = startPointId;
    edge.endPointId = endPointId;
    edge.bridgePoints = bridgePoints;
    edge.id = Id::GetId(Type::EDGE);

    uint32_t id = edge.id;
    uint32_t index = edges.size() - 1;
    edgeIdToIndex[id] = index;

    for (uint32_t pointId : bridgePoints)
        RegisterDependency(pointId, id);

    LOG_VOID("Created poly line edge");

    return id;
}

uint32_t Scene::CreateArcCurve(glm::dvec3 centerPosition, double radius)
{
    ArcData arc;
    arc.center = centerPosition;
    arc.radius = radius;

    curves.emplace_back();

    Curve &curve = curves.back();
    curve.data.operator=(arc);
    curve.id = Id::GetId(Type::CURVE);
    curve.type = CurveType::ARC;

    uint32_t id = curve.id;
    uint32_t index = curves.size() - 1;
    curveIdToIndex[id] = index;

    LOG_VOID("Created arc curve");

    return id;
}

uint32_t Scene::CreateNURBSCurve(const tinynurbs::RationalCurve3d &nurbs)
{
    curves.emplace_back();

    Curve &curve = curves.back();
    curve.data = std::make_unique<tinynurbs::RationalCurve3d>(nurbs);
    curve.id = Id::GetId(Type::CURVE);
    curve.type = CurveType::NURBS;

    uint32_t id = curve.id;
    uint32_t index = curves.size() - 1;
    curveIdToIndex[id] = index;

    LOG_VOID("Created nurbs curve");

    return id;
}

uint32_t Scene::CreatePlanarFace(const std::vector<std::vector<uint32_t>> &edgeLoops)
{
    faces.emplace_back();

    Face &face = faces.back();
    face.loops = edgeLoops;
    face.id = Id::GetId(Type::FACE);

    uint32_t id = face.id;
    uint32_t index = faces.size() - 1;
    faceIdToIndex[id] = index;

    for (std::vector<uint32_t> edgeLoop : edgeLoops)
    {
        for (uint32_t edgeId : edgeLoop)
            RegisterDependency(edgeId, id);
    }

    LOG_VOID("Created planar face");

    return id;
}

uint32_t Scene::CreateNURBSFace(const std::vector<std::vector<uint32_t>> &edgeLoops, const tinynurbs::RationalSurface3d &nurbs)
{
    faces.emplace_back();

    Face &face = faces.back();
    face.loops = edgeLoops;
    face.surface = std::make_unique<tinynurbs::RationalSurface3d>(nurbs);
    face.id = Id::GetId(Type::FACE);

    uint32_t id = face.id;
    uint32_t index = faces.size() - 1;
    faceIdToIndex[id] = index;

    for (std::vector<uint32_t> edgeLoop : edgeLoops)
    {
        for (uint32_t edgeId : edgeLoop)
            RegisterDependency(edgeId, id);
    }

    LOG_VOID("Created nurbs face");

    return id;
}

uint32_t Scene::CreateSolid(const std::vector<uint32_t> &faces)
{
    solids.emplace_back();

    Solid &solid = solids.back();
    solid.faceIds = faces;
    solid.id = Id::GetId(Type::SOLID);

    uint32_t id = solid.id;
    uint32_t index = solids.size() - 1;
    solidIdToIndex[id] = index;

    LOG_VOID("Created solid");

    return id;
}

const Point *Scene::GetPoint(uint32_t id) const
{
    auto hash = pointIdToIndex.find(id);
    if (hash == pointIdToIndex.end())
    {
        return nullptr;
    }
    return &points[hash->second];
}

const Edge *Scene::GetEdge(uint32_t id) const
{
    auto hash = edgeIdToIndex.find(id);
    if (hash == edgeIdToIndex.end())
        return nullptr;
    return &edges[hash->second];
}

const Curve *Scene::GetCurve(uint32_t id) const
{
    auto hash = curveIdToIndex.find(id);
    if (hash == curveIdToIndex.end())
    {
        return nullptr;
    }
    return &curves[hash->second];
}

Curve *Scene::GetCurve(uint32_t id)
{
    auto hash = curveIdToIndex.find(id);
    if (hash == curveIdToIndex.end())
    {
        return nullptr;
    }
    return &curves[hash->second];
}

const Face *Scene::GetFace(uint32_t id) const
{
    auto hash = faceIdToIndex.find(id);
    if (hash == faceIdToIndex.end())
    {
        return nullptr;
    }
    return &faces[hash->second];
}

Face *Scene::GetFace(uint32_t id)
{
    auto hash = faceIdToIndex.find(id);
    if (hash == faceIdToIndex.end())
    {
        return nullptr;
    }
    return &faces[hash->second];
}

const Solid *Scene::GetSolid(uint32_t id) const
{
    auto hash = solidIdToIndex.find(id);
    if (hash == solidIdToIndex.end())
    {
        return nullptr;
    }
    return &solids[hash->second];
}

void Scene::RegisterDependency(uint32_t formId, uint32_t dependancyId)
{
    dependencies[formId].insert(dependancyId);
}

void Scene::UnregisterDependency(uint32_t formId, uint32_t dependancyId)
{
    auto it = dependencies.find(dependancyId);
    if (it != dependencies.end())
    {
        it->second.erase(formId);

        if (it->second.empty())
            dependencies.erase(it);
    }
}

bool Scene::DeletePoint(uint32_t id)
{
    auto it = pointIdToIndex.find(id);
    if (it == pointIdToIndex.end())
        return false;

    uint32_t index = it->second;

    if (index != points.size() - 1)
    {
        std::swap(points[index], points.back());
        pointIdToIndex[points[index].id] = index;
    }

    points.pop_back();
    pointIdToIndex.erase(id);
    dependencies.erase(id);

    return true;
}

bool Scene::DeleteEdge(uint32_t id)
{
    auto it = edgeIdToIndex.find(id);
    if (it == edgeIdToIndex.end())
    {
        return false;
    }

    uint32_t index = it->second;

    if (index != edges.size() - 1)
    {
        std::swap(edges[index], edges.back());
        pointIdToIndex[edges[index].id] = index;
    }

    edges.pop_back();
    edgeIdToIndex.erase(id);
    dependencies.erase(id);

    return true;
}

bool Scene::DeleteCurve(uint32_t id)
{
    auto it = curveIdToIndex.find(id);
    if (it == curveIdToIndex.end())
    {
        return false;
    }

    uint32_t index = it->second;

    if (index != curves.size() - 1)
    {
        std::swap(curves[index], curves.back());
        pointIdToIndex[curves[index].id] = index;
    }

    curves.pop_back();
    curveIdToIndex.erase(id);
    dependencies.erase(id);

    return true;
}

bool Scene::DeleteFace(uint32_t id)
{
    auto it = faceIdToIndex.find(id);
    if (it == faceIdToIndex.end())
    {
        return false;
    }

    uint32_t index = it->second;

    if (index != faces.size() - 1)
    {
        std::swap(faces[index], faces.back());
        pointIdToIndex[faces[index].id] = index;
    }

    faces.pop_back();
    faceIdToIndex.erase(id);
    dependencies.erase(id);

    return true;
}

bool Scene::DeleteSolid(uint32_t id)
{
    auto it = solidIdToIndex.find(id);
    if (it == solidIdToIndex.end())
    {
        return false;
    }

    uint32_t index = it->second;

    if (index != solids.size() - 1)
    {
        std::swap(solids[index], solids.back());
        pointIdToIndex[solids[index].id] = index;
    }

    solids.pop_back();
    solidIdToIndex.erase(id);
    dependencies.erase(id);

    return true;
}