#include "Analysis.hpp"

Flaw Analysis::GetFlaw(uint32_t id, const Scene &scene)
{
    Flaw flaw = Flaw::OVERHANG;
    const Face *face = scene.GetFace(id);

    return flaw;
}