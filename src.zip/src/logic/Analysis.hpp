#include <vector>
#include "scene/scene.hpp"

enum class Flaw
{
    OVERHANG,
    NONE
};

class Analysis
{
public:
    static Flaw GetFlaw(uint32_t face, const Scene &scene);
};