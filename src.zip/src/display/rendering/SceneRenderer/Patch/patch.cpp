#include "patch.hpp"

void Patch::Generate(const Scene &scene, const RenderBuffer &buffer, std::vector<Vertex> &vertices, std::vector<uint32_t> &indices, int viewport[4]) const
{
    for (uint32_t id : buffer.GetForms())
    {
        Type type = Id::GetType(id);
        switch (type)
        {
        case Type::FACE:
            AddFace(scene, id, vertices, indices);
            break;

        case Type::SOLID:
            AddSolid(scene, id, vertices, indices);
            break;

        default:
            break;
        }
    }
}

void Patch::AddFace(const Scene &scene, uint32_t faceId,
                    std::vector<Vertex> &vertices,
                    std::vector<uint32_t> &indices) const
{
    const Face *face = scene.GetFace(faceId);
    if (face == nullptr || face->loops.empty())
        return;

    using Point2D = std::array<double, 2>;
    std::vector<std::vector<Point2D>> polygon;
    std::vector<std::vector<glm::dvec3>> allLoopPositions;

    for (const auto &edgeLoop : face->loops)
    {
        std::vector<glm::dvec3> loopPositions;
        for (const auto &edgeId : edgeLoop)
        {
            const Edge *edge = scene.GetEdge(edgeId);
            if (edge == nullptr)
                continue;

            const Point *p0 = scene.GetPoint(edge->startPointId);
            const Point *p1 = scene.GetPoint(edge->endPointId);
            if (p0 == nullptr || p1 == nullptr)
                continue;

            if (edge->curveId == 0)
            {
                loopPositions.push_back(p0->position);
            }
            else
            {
                const Curve *curve = scene.GetCurve(edge->curveId);

                std::vector<glm::dvec3> tessellatedPoints = TessellateCurveToPoints(curve, p0->position, p1->position, 16);

                for (size_t i = 0; i < tessellatedPoints.size() - 1; i++)
                {
                    loopPositions.push_back(tessellatedPoints[i]);
                }
            }
        }

        allLoopPositions.push_back(loopPositions);

        std::vector<Point2D> loop2D;
        for (const glm::dvec3 &pos : loopPositions)
        {
            loop2D.push_back({pos.x, pos.y});
        }
        polygon.push_back(loop2D);
    }

    if (polygon.empty())
        return;

    std::vector<uint32_t> triangleIndices = mapbox::earcut<uint32_t>(polygon);

    if (triangleIndices.empty())
        return;

    uint32_t baseVertexIndex = vertices.size();

    for (const auto &loopPositions : allLoopPositions)
    {
        for (const glm::dvec3 &pos : loopPositions)
        {
            Vertex v;
            v.position = glm::vec3(pos);
            v.color = Color::GetFace(faceId, scene);

            vertices.push_back(v);
        }
    }

    for (uint32_t idx : triangleIndices)
    {
        indices.push_back(baseVertexIndex + idx);
    }
}

void Patch::AddSolid(const Scene &scene, uint32_t id,
                     std::vector<Vertex> &vertices,
                     std::vector<uint32_t> &indices) const
{
    const Solid *solid = scene.GetSolid(id);
    if (solid == nullptr)
    {
        return;
    }

    for (uint32_t faceId : solid->faceIds)
    {
        AddFace(scene, faceId, vertices, indices);
    }
}

std::vector<glm::dvec3> Patch::TessellateCurveToPoints(
    const Curve *curve,
    const glm::dvec3 &start,
    const glm::dvec3 &end,
    int segments) const
{
    std::vector<glm::dvec3> points;
    if (curve == nullptr)
    {
        points.push_back(start);
        points.push_back(end);
        return points;
    }

    for (int i = 0; i <= segments + 1; i++)
    {
        double t = (double)i / segments;
        glm::dvec3 p = curve->Evaluate(t, start, end);
        points.push_back(p);
    }
    return points;
}